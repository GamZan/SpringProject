package com.example.Springtest

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.ComponentScan

@SpringBootApplication
class SpringTestApplication

fun main(args: Array<String>) {
	runApplication<SpringTestApplication>(*args)
}



