package com.example.Springtest.dto

import java.time.LocalDate


data class TestDto (
        var name: String,
        var birthDay: LocalDate
)
