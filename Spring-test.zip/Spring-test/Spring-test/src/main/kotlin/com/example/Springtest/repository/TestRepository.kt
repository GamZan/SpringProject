package com.example.Springtest.repository

import com.example.Springtest.entity.Test
import org.springframework.data.jpa.repository.JpaRepository

interface TestRepository : JpaRepository<Test, String>