package com.example.Springtest.entity

import jakarta.persistence.Entity
import jakarta.persistence.Id
import org.hibernate.proxy.HibernateProxy
import java.time.LocalDate
import java.time.LocalDateTime

@Entity
class Test(
        @Id
        var id: String,
        var name: String,
        var birthDay: LocalDate,
        var createdAt: LocalDateTime
)