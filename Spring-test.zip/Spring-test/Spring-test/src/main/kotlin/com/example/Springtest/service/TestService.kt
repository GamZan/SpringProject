package com.example.Springtest.service

import com.example.Springtest.dto.TestDto
import com.example.Springtest.entity.Test
import com.example.Springtest.repository.TestRepository
import org.springframework.stereotype.Service
import java.time.LocalDateTime
import java.util.UUID

@Service
class TestService(private val testRepository: TestRepository) {

    fun save(testDto: TestDto): Test {
        val test: Test = Test(
                name = testDto.name,
                birthDay = testDto.birthDay,
                id = (UUID.randomUUID().toString()),
                createdAt = (LocalDateTime.now())
        )
        val name = testDto.name
        return testRepository.save(test)
    }

    fun getAll(): Iterable<Test> {
        return testRepository.findAll()
    }
}