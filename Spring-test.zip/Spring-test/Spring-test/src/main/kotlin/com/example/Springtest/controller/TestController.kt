package com.example.Springtest.controller

import com.example.Springtest.dto.TestDto
import com.example.Springtest.entity.Test
import com.example.Springtest.service.TestService
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/v1/example")
class TestController(private val testService: TestService) {

    private val service = testService

    @PostMapping
    fun save(@RequestBody test: TestDto): Test {
        return service.save(test)
    }

    @GetMapping
    fun getAll(): Iterable<Test> {
        return service.getAll()
    }
}